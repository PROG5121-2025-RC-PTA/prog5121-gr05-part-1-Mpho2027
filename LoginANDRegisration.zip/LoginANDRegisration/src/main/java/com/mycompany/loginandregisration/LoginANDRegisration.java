/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loginandregisration;
import javax.swing.*;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author RC_Student_lab
 */
public class LoginANDRegisration {
    // Storing user credentials here 
    private static final Map<String, User> usersDatabase = new HashMap<>();
    
    public static void main(String[] args) {
        // Main menu side for choice purposes 
        while(true) {
            String[] options = {"Register", "Login", "Exit"};
            int choice = JOptionPane.showOptionDialog(null,
                "Welcome to Account System\nPlease choose an option:",
                "Main Menu",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                options,
                options[0]);
            // choice functions using an if function 
            if(choice == 0) {
                registerUser();
            } else if(choice == 1) {
                loginUser();
            } else {
                System.exit(0);
            }
        }
    }
    
    // User registration process
    static void registerUser() {
        // Get first and last name
        String firstName = JOptionPane.showInputDialog("Enter your first name:");
        if(firstName == null) return;
        
        String lastName = JOptionPane.showInputDialog("Enter your last name:");
        if(lastName == null) return;
        
        // Username validation
        String username = "";
        while(true) {
            username = JOptionPane.showInputDialog(
                "Create username (must have _ and be ≤5 characters):");
            
            if(username == null) return;
            
            if(username.contains("_") && username.length() <= 5) {
                break;
            } else {
                JOptionPane.showMessageDialog(null,
                    "Invalid! Needs _ and ≤5 characters",
                    "Try Again", JOptionPane.WARNING_MESSAGE);
            }
        }
        
        // Password validation
        String password = "";
        while(true) {
            password = JOptionPane.showInputDialog("""
                                                   Create password with:
                                                   - 8+ characters
                                                   - 1 capital letter
                                                   - 1 number
                                                   - 1 special character (!@#$ etc)""");
            
            if(password == null) return;
            
            boolean hasUpper = !password.equals(password.toLowerCase());
            boolean hasDigit = password.matches(".*\\d.*");
            boolean hasSpecial = !password.matches("[A-Za-z0-9]*");
            
            if(password.length() >= 8 && hasUpper && hasDigit && hasSpecial) {
                break;
            } else {
                JOptionPane.showMessageDialog(null,
                    "Password missing requirements:\n" +
                    (password.length() < 8 ? "- Needs 8+ characters\n" : "") +
                    (!hasUpper ? "- Needs capital letter\n" : "") +
                    (!hasDigit ? "- Needs number\n" : "") +
                    (!hasSpecial ? "- Needs special character" : ""),
                    "Try Again", JOptionPane.WARNING_MESSAGE);
            }
        }
        
        // Phone validation
        String phone = "";
        while(true) {
            phone = JOptionPane.showInputDialog(
                "Enter phone with country code (like +1234567890):");
            
            if(phone == null) return;
            
            if(phone.startsWith("+") && phone.length() == 11 && 
               phone.substring(1).matches("\\d+")) {
                break;
            } else {
                JOptionPane.showMessageDialog(null,
                    "Phone must be + followed by 10 digits",
                    "Try Again", JOptionPane.WARNING_MESSAGE);
            }
        }
        
        // Store user data
        usersDatabase.put(username, new User(firstName, lastName, password, phone));
        JOptionPane.showMessageDialog(null,
            "Registration successful!",
            "Success", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // User logn here 
    static void loginUser() {
        if(usersDatabase.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                "No users registered yet!",
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        while(true) {
            String username = JOptionPane.showInputDialog("Enter your username:");
            if(username == null) return;
            
            String password = JOptionPane.showInputDialog("Enter your password:");
            if(password == null) return;
            
            if(usersDatabase.containsKey(username)) {
                User user = usersDatabase.get(username);
                if(user.password.equals(password)) {
                    JOptionPane.showMessageDialog(null,
                        "Welcome " + user.firstName + ", " + user.lastName + 
                        " it is great to see you again.",
                        "Login Successful", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
            }
            
            JOptionPane.showMessageDialog(null,
                "Username or password incorrect, please try again.",
                "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // data class
    static class User {
        String firstName;
        String lastName;
        String password;
        String phone;
        
        User(String firstName, String lastName, String password, String phone) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.password = password;
            this.phone = phone;
        }
    }
}
    